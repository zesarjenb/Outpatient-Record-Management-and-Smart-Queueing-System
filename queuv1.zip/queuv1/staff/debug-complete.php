<?php
// staff/registration.php - Patient Registration with CRM Integration & Email Feature
// Camp Evangelista Station Hospital
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('log_errors', 1);
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/patient-validation.php';
require_once dirname(__DIR__) . '/includes/QueueManager.php';

session_start();

// ============================================
// AUTHENTICATION & ROLE-BASED ACCESS CONTROL
// ============================================

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

$allowed_staff_roles = ['admin', 'doctor', 'nurse', 'technician', 'staff'];
if (!in_array($_SESSION['role'], $allowed_staff_roles)) {
    header('Location: ../unauthorized.php');
    exit();
}

// ============================================
// DATABASE CONNECTIONS
// ============================================
$database = new Database();
$db = $database->getConnection();
$crm_db = $database->getCRMConnection();
$queueManager = new QueueManager($db);

// ============================================
// SESSION TIMEOUT CHECK
// ============================================
require_once dirname(__DIR__) . '/includes/SessionManager.php';
$sessionManager = new SessionManager($db);
if (!$sessionManager->checkTimeout()) {
    exit();
}

// Get clinics for dropdown
$query = "SELECT * FROM clinics WHERE is_active = 1 ORDER BY clinic_order ASC, name ASC";
$clinics = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);

// Get existing patients from CRM
$crm_patients = [];
if ($crm_db) {
    try {
        $crm_query = "SELECT mrn, first_name, last_name, dob, gender, contact, address 
                      FROM patients 
                      WHERE status = 'Active' 
                      ORDER BY last_name ASC, first_name ASC";
        $crm_stmt = $crm_db->prepare($crm_query);
        $crm_stmt->execute();
        $crm_patients = $crm_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("CRM Patient fetch error: " . $e->getMessage());
        $crm_patients = [];
    }
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function generateQueueMRN($db) {
    $max_attempts = 5;
    for ($attempt = 1; $attempt <= $max_attempts; $attempt++) {
        $mrn = 'MRN' . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $check = $db->prepare("SELECT id FROM patients WHERE mrn = ? LIMIT 1");
        $check->execute([$mrn]);
        if (!$check->fetch()) {
            return $mrn;
        }
    }
    return 'MRN' . date('YmdHis') . rand(10, 99);
}

function isDuplicatePatient($db, $first_name, $last_name, $dob, $gender, $exclude_id = null) {
    $query = "SELECT id FROM patients 
              WHERE first_name = :first_name 
              AND last_name = :last_name 
              AND date_of_birth = :dob 
              AND gender = :gender";
    if ($exclude_id) {
        $query .= " AND id != :exclude_id";
    }
    $stmt = $db->prepare($query);
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':dob', $dob);
    $stmt->bindParam(':gender', $gender);
    if ($exclude_id) {
        $stmt->bindParam(':exclude_id', $exclude_id);
    }
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function validateMobileNumber($number) {
    $clean = preg_replace('/[^0-9]/', '', $number);
    if (strlen($clean) != 11) return false;
    if (!preg_match('/^09[0-9]{9}$/', $clean)) return false;
    return true;
}

// ============================================
// EMAIL VALIDATION FUNCTION
// ============================================
function validateEmail($email) {
    if (empty($email)) return true; // Email is optional
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// ============================================
// FORM SUBMISSION HANDLING
// ============================================

$success_message = '';
$error_message = '';
$last_registered_patient = null;
$registered_clinics = [];
$form_errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register_patient'])) {
    
    $form_errors = [];
    
    // Check if using existing patient from CRM
    $use_existing = isset($_POST['use_existing']) && $_POST['use_existing'] == '1';
    $existing_mrn = isset($_POST['existing_mrn']) ? (int)$_POST['existing_mrn'] : 0;
    
    // Get name fields
    $first_name = isset($_POST['first_name']) && is_string($_POST['first_name']) ? trim($_POST['first_name']) : '';
    $middle_name = isset($_POST['middle_name']) && is_string($_POST['middle_name']) ? trim($_POST['middle_name']) : '';
    $last_name = isset($_POST['last_name']) && is_string($_POST['last_name']) ? trim($_POST['last_name']) : '';
    $suffix = isset($_POST['suffix']) && is_string($_POST['suffix']) ? trim($_POST['suffix']) : '';
    $dob = isset($_POST['dob']) ? $_POST['dob'] : '';
    $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
    $contact = isset($_POST['contact']) ? trim($_POST['contact']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';  // <-- ADDED
    $address = isset($_POST['address']) ? trim($_POST['address']) : '';
    $patient_type = isset($_POST['patient_type']) ? $_POST['patient_type'] : '';
    $is_pwd = isset($_POST['is_pwd']) ? 1 : 0;
    $is_senior = isset($_POST['is_senior']) ? 1 : 0;
    $is_pregnant = isset($_POST['is_pregnant']) ? 1 : 0;

    foreach ([$first_name, $middle_name, $last_name, $suffix] as $name) {
        if (!isValidPatientName($name, true)) {
            $form_errors[] = "Name fields may contain letters, spaces, and hyphens (-) only.";
            break;
        }
    }
    
    // Validate email if provided
    if (!empty($email) && !validateEmail($email)) {
        $form_errors[] = "Please enter a valid email address.";
    }
    
    if ($use_existing && $existing_mrn > 0 && $crm_db) {
        try {
            $crm_fetch = "SELECT mrn, first_name, last_name, dob, gender, contact, address 
                          FROM patients WHERE mrn = :mrn";
            $crm_fetch_stmt = $crm_db->prepare($crm_fetch);
            $crm_fetch_stmt->bindParam(':mrn', $existing_mrn, PDO::PARAM_INT);
            $crm_fetch_stmt->execute();
            $existing_patient = $crm_fetch_stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing_patient) {
                $crm_first_name = $existing_patient['first_name'] ?? '';
                $crm_last_name = $existing_patient['last_name'] ?? '';
                $crm_dob = $existing_patient['dob'] ?? '';
                $crm_gender = $existing_patient['gender'] ?? '';
                $crm_contact = $existing_patient['contact'] ?? '';
                $crm_address = $existing_patient['address'] ?? '';
                
                if (empty($first_name)) $first_name = $crm_first_name;
                if (empty($last_name)) $last_name = $crm_last_name;
                if (empty($dob)) $dob = $crm_dob;
                if (empty($gender)) $gender = $crm_gender;
                if (empty($contact)) $contact = $crm_contact;
                if (empty($address)) $address = $crm_address;

                foreach ([$first_name, $middle_name, $last_name, $suffix] as $name) {
                    if (!isValidPatientName($name, true)) {
                        $form_errors[] = "Name fields may contain letters, spaces, and hyphens (-) only.";
                        break;
                    }
                }
                
                if (!empty($contact) && !validateMobileNumber($contact)) {
                    $form_errors[] = "Contact number must be 11 digits and start with 09 (e.g., 09123456789).";
                }
                if (empty($address)) {
                    $form_errors[] = "Address is required.";
                }
                
                if (empty($form_errors)) {
                    $mrn_string = 'MRN' . str_pad($existing_mrn, 6, '0', STR_PAD_LEFT);
                    $check_local = "SELECT id, middle_name, suffix, patient_type, email FROM patients WHERE mrn = :mrn LIMIT 1";
                    $check_stmt = $db->prepare($check_local);
                    $check_stmt->bindParam(':mrn', $mrn_string);
                    $check_stmt->execute();
                    $local_patient = $check_stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($local_patient) {
                        $patient_id = $local_patient['id'];
                        $update_fields = [];
                        $update_values = [];
                        
                        if (empty($local_patient['middle_name']) && !empty($middle_name)) {
                            $update_fields[] = "middle_name = :middle_name";
                            $update_values[':middle_name'] = $middle_name;
                        }
                        if (empty($local_patient['suffix']) && !empty($suffix)) {
                            $update_fields[] = "suffix = :suffix";
                            $update_values[':suffix'] = $suffix;
                        }
                        if (!empty($contact) && $contact != $crm_contact) {
                            $update_fields[] = "contact_number = :contact";
                            $update_values[':contact'] = $contact;
                        }
                        if (!empty($email) && empty($local_patient['email'])) {
                            $update_fields[] = "email = :email";  // <-- ADDED
                            $update_values[':email'] = $email;
                        }
                        if (!empty($address)) {
                            $update_fields[] = "address = :address";
                            $update_values[':address'] = $address;
                        }
                        if ($local_patient['patient_type'] != $patient_type) {
                            $update_fields[] = "patient_type = :patient_type";
                            $update_values[':patient_type'] = $patient_type;
                        }
                        
                        if (!empty($update_fields)) {
                            $update_sql = "UPDATE patients SET " . implode(', ', $update_fields) . " WHERE id = :id";
                            $update_stmt = $db->prepare($update_sql);
                            foreach ($update_values as $key => $value) {
                                $update_stmt->bindValue($key, $value);
                            }
                            $update_stmt->bindParam(':id', $patient_id);
                            $update_stmt->execute();
                        }
                    } else {
                        $insert_local = "INSERT INTO patients 
                                        (mrn, first_name, middle_name, last_name, suffix, date_of_birth, gender, 
                                         contact_number, email, address, patient_type, created_at) 
                                        VALUES 
                                        (:mrn, :first_name, :middle_name, :last_name, :suffix, :dob, :gender, 
                                         :contact, :email, :address, :patient_type, NOW())";
                        $insert_stmt = $db->prepare($insert_local);
                        $insert_stmt->bindParam(':mrn', $mrn_string);
                        $insert_stmt->bindParam(':first_name', $first_name);
                        $insert_stmt->bindParam(':middle_name', $middle_name);
                        $insert_stmt->bindParam(':last_name', $last_name);
                        $insert_stmt->bindParam(':suffix', $suffix);
                        $insert_stmt->bindParam(':dob', $dob);
                        $insert_stmt->bindParam(':gender', $gender);
                        $insert_stmt->bindParam(':contact', $contact);
                        $insert_stmt->bindParam(':email', $email);
                        $insert_stmt->bindParam(':address', $address);
                        $insert_stmt->bindParam(':patient_type', $patient_type);
                        $insert_stmt->execute();
                        $patient_id = $db->lastInsertId();
                    }
                    
                    $mrn = $mrn_string;
                }
            } else {
                $form_errors[] = "Selected patient not found in CRM.";
            }
        } catch (PDOException $e) {
            $form_errors[] = "Error accessing CRM: " . $e->getMessage();
            error_log("CRM fetch error: " . $e->getMessage());
        }
    } else {
        // ============================================
        // NEW PATIENT REGISTRATION (Queue System Only)
        // ============================================
        
        if (empty($first_name)) $form_errors[] = "First name is required.";
        if (empty($last_name)) $form_errors[] = "Last name is required.";
        if (empty($dob)) $form_errors[] = "Date of birth is required.";
        if (empty($gender)) $form_errors[] = "Gender is required.";
        if (empty($patient_type)) $form_errors[] = "Patient type is required.";
        if (empty($contact)) {
            $form_errors[] = "Contact number is required.";
        } elseif (!validateMobileNumber($contact)) {
            $form_errors[] = "Contact number must be 11 digits and start with 09 (e.g., 09123456789).";
        }
        if (empty($address)) $form_errors[] = "Address is required.";
        if (!empty($email) && !validateEmail($email)) {
            $form_errors[] = "Please enter a valid email address.";
        }
        
        if (!empty($dob)) {
            $dob_date = strtotime($dob);
            $today = strtotime(date('Y-m-d'));
            if ($dob_date > $today) {
                $form_errors[] = "Date of birth cannot be a future date.";
            }
            $age = date('Y') - date('Y', $dob_date);
            if ($age > 120) {
                $form_errors[] = "Age cannot exceed 120 years.";
            }
        }
        
        if (empty($form_errors)) {
            $duplicate = isDuplicatePatient($db, $first_name, $last_name, $dob, $gender);
            if ($duplicate) {
                $form_errors[] = "A patient with the same name, date of birth, and gender already exists. Please use 'Existing Patient'.";
            }
        }
        
        if (empty($form_errors)) {
            $mrn = generateQueueMRN($db);
            
            $insert = "INSERT INTO patients 
                      (mrn, first_name, middle_name, last_name, suffix, date_of_birth, gender, 
                       contact_number, email, address, patient_type, is_pwd, is_senior, is_pregnant, created_at) 
                      VALUES 
                      (:mrn, :first_name, :middle_name, :last_name, :suffix, :dob, :gender, 
                       :contact, :email, :address, :patient_type, :is_pwd, :is_senior, :is_pregnant, NOW())";
            $stmt = $db->prepare($insert);
            $stmt->bindParam(':mrn', $mrn);
            $stmt->bindParam(':first_name', $first_name);
            $stmt->bindParam(':middle_name', $middle_name);
            $stmt->bindParam(':last_name', $last_name);
            $stmt->bindParam(':suffix', $suffix);
            $stmt->bindParam(':dob', $dob);
            $stmt->bindParam(':gender', $gender);
            $stmt->bindParam(':contact', $contact);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':address', $address);
            $stmt->bindParam(':patient_type', $patient_type);
            $stmt->bindParam(':is_pwd', $is_pwd);
            $stmt->bindParam(':is_senior', $is_senior);
            $stmt->bindParam(':is_pregnant', $is_pregnant);
            if ($stmt->execute()) {
                $patient_id = $db->lastInsertId();
            } else {
                $form_errors[] = "Error registering patient. Please try again.";
            }
        }
    }
    
    // ============================================
    // QUEUE REGISTRATION
    // ============================================
    
     if (empty($form_errors) && isset($patient_id)) {
        $selected_clinics = isset($_POST['clinic_ids']) ? $_POST['clinic_ids'] : [];
        
        // Military patient
         if ($patient_type == 'military') {
             // Get ALL active clinics sorted by congestion (least congested first)
                 $all_clinics = $queueManager->getAllClinicsByCongestion();
            
            if (!empty($all_clinics)) {
        // First clinic is the least congested
        $first_clinic = $all_clinics[0];
        $first_clinic_id = $first_clinic['id'];

        $queue_result = $queueManager->addToQueue($patient_id, $first_clinic_id, null);
                
                if ($queue_result && $queue_result['success']) {
                    $remaining_clinics = array_slice($all_clinics_list, 1);
                    $remaining_ids = array_column($remaining_clinics, 'id');

                    if (!empty($remaining_ids)) {
                        $queueManager->storePatientJourney($patient_id, $remaining_ids);
                    }
                    
                    $full_name = $first_name . ' ' . ($middle_name ? $middle_name . ' ' : '') . $last_name . ($suffix ? ' ' . $suffix : '');
                    $success_message = "Patient registered successfully!";
                    $success_message .= "<br><strong>Full Name:</strong> " . htmlspecialchars($full_name);
                    $success_message .= "<br><strong>MRN:</strong> " . $mrn;

                    if (!empty($email)) {
                        $success_message .= "<br><strong>Email:</strong> " . htmlspecialchars($email);
                    }
                    $success_message .= "<br><strong>Queue Number:</strong> " . $queue_result['queue_number'];
                    $success_message .= "<br><strong>Transaction Token:</strong> <code>" . $queue_result['transaction_token'] . "</code>";
                    $success_message .= "<br><br><strong>Medical Journey:</strong> Patient will be automatically queued for all clinics in sequence.";
                    
                    $last_registered_patient = [
                        'patient_id' => $patient_id,
                        'mrn' => $mrn,
                        'queue_number' => $queue_result['queue_number'],
                        'transaction_token' => $queue_result['transaction_token']
                    ];
                    
                    // ============================================
                    // SEND EMAIL NOTIFICATION - MILITARY
                    // ============================================
                    error_log("📧 MILITARY - Email check: " . (!empty($email) ? $email : "NO EMAIL PROVIDED"));
                    if (!empty($email) && $last_registered_patient['queue_number']) {
                        require_once dirname(__DIR__) . '/includes/SimpleEmailSender.php';
                        
                        $emailSender = new SimpleEmailSender();
                        $patient_name = $first_name . ' ' . ($middle_name ? $middle_name . ' ' : '') . $last_name . ($suffix ? ' ' . $suffix : '');
                        $queue_number = $last_registered_patient['queue_number'];
                        $transaction_token = $last_registered_patient['transaction_token'];
                        $clinic_name = "ALL Clinics (Sequential Order)";
                        
                        $sent = $emailSender->sendNotification($email, $patient_name, $queue_number, $transaction_token, $clinic_name);
                        
                        if ($sent) {
                            $success_message .= "<br><br><i class='fas fa-envelope text-emerald-500'></i> <strong>Email notification sent to:</strong> " . htmlspecialchars($email);
                        } else {
                            error_log("Failed to send email notification to: $email");
                        }
                    }
                    
                } else {
                    $error_message = "Error adding patient to queue.";
                }
            } else {
                $error_message = "No active clinics found.";
            }
             } 
                // Dependent with multiple clinics
                 elseif (!empty($selected_clinics) && count($selected_clinics) > 0) {
            $appointment_time = !empty($_POST['appointment_time']) ? $_POST['appointment_time'] : null;
            $first_clinic_id = $selected_clinics[0];
            $queue_result = $queueManager->addToQueue($patient_id, $first_clinic_id, $appointment_time);
            
            if ($queue_result && $queue_result['success']) {
                $remaining_clinics = array_slice($selected_clinics, 1);
                if (!empty($remaining_clinics)) {
                    $queueManager->storePatientJourney($patient_id, $remaining_clinics);
                }
                
                foreach ($selected_clinics as $clinic_id) {
                    $clinic_name_query = "SELECT name FROM clinics WHERE id = :id";
                    $clinic_name_stmt = $db->prepare($clinic_name_query);
                    $clinic_name_stmt->bindParam(':id', $clinic_id);
                    $clinic_name_stmt->execute();
                    $clinic_info = $clinic_name_stmt->fetch(PDO::FETCH_ASSOC);
                    if ($clinic_info) $registered_clinics[] = $clinic_info['name'];
                }
                
                $full_name = $first_name . ' ' . ($middle_name ? $middle_name . ' ' : '') . $last_name . ($suffix ? ' ' . $suffix : '');
                $success_message = "Patient registered successfully!";
                $success_message .= "<br><strong>Full Name:</strong> " . htmlspecialchars($full_name);
                $success_message .= "<br><strong>MRN:</strong> " . $mrn;
                if (!empty($email)) {
                    $success_message .= "<br><strong>Email:</strong> " . htmlspecialchars($email);
                }
                $success_message .= "<br><strong>Queue Number:</strong> " . $queue_result['queue_number'];
                $success_message .= "<br><strong>Transaction Token:</strong> <code>" . $queue_result['transaction_token'] . "</code>";
                $success_message .= "<br><strong>Clinic Journey:</strong> " . implode(" → ", $registered_clinics);
                $success_message .= "<br><em>Patient will be automatically queued for each clinic after completing the previous one.</em>";
                
                $last_registered_patient = [
                    'patient_id' => $patient_id,
                    'mrn' => $mrn,
                    'queue_number' => $queue_result['queue_number'],
                    'transaction_token' => $queue_result['transaction_token']
                ];
                
                // ============================================
                // SEND EMAIL NOTIFICATION - DEPENDENT WITH JOURNEY
                // ============================================
                if (!empty($email) && $last_registered_patient['queue_number']) {
                    require_once dirname(__DIR__) . '/includes/SimpleEmailSender.php';
                    
                    $emailSender = new SimpleEmailSender();
                    $patient_name = $first_name . ' ' . ($middle_name ? $middle_name . ' ' : '') . $last_name . ($suffix ? ' ' . $suffix : '');
                    $queue_number = $last_registered_patient['queue_number'];
                    $transaction_token = $last_registered_patient['transaction_token'];
                    $clinic_name = implode(" → ", $registered_clinics);
                    
                    $sent = $emailSender->sendNotification($email, $patient_name, $queue_number, $transaction_token, $clinic_name);
                    
                    if ($sent) {
                        $success_message .= "<br><br><i class='fas fa-envelope text-emerald-500'></i> <strong>Email notification sent to:</strong> " . htmlspecialchars($email);
                    } else {
                        error_log("Failed to send email notification to: $email");
                    }
                }
                
            } else {
                $error_message = "Error adding patient to queue.";
            }
         }
            // Register only (no queue)
            else {
            $full_name = $first_name . ' ' . ($middle_name ? $middle_name . ' ' : '') . $last_name . ($suffix ? ' ' . $suffix : '');
            $success_message = "Patient registered successfully!";
            $success_message .= "<br><strong>Full Name:</strong> " . htmlspecialchars($full_name);
            $success_message .= "<br><strong>MRN:</strong> " . $mrn;
            if (!empty($email)) {
                $success_message .= "<br><strong>Email:</strong> " . htmlspecialchars($email);
            }
            $success_message .= "<br><strong>Note:</strong> No clinic selected. Patient registered without queue assignment.";
            
            $last_registered_patient = [
                'patient_id' => $patient_id,
                'mrn' => $mrn,
                'queue_number' => null,
                'transaction_token' => null
            ];
            
            // ============================================
            // SEND EMAIL NOTIFICATION - REGISTER ONLY (No Queue)
            // ============================================
            if (!empty($email)) {
                require_once dirname(__DIR__) . '/includes/SimpleEmailSender.php';
                
                $emailSender = new SimpleEmailSender();
                $patient_name = $first_name . ' ' . ($middle_name ? $middle_name . ' ' : '') . $last_name . ($suffix ? ' ' . $suffix : '');
                $queue_number = "N/A (No clinic selected)";
                $transaction_token = "N/A";
                $clinic_name = "No clinic assigned";
                
                $sent = $emailSender->sendNotification($email, $patient_name, $queue_number, $transaction_token, $clinic_name);
                
                if ($sent) {
                    $success_message .= "<br><br><i class='fas fa-envelope text-emerald-500'></i> <strong>Email notification sent to:</strong> " . htmlspecialchars($email);
                } else {
                    error_log("Failed to send email notification to: $email");
                }
            }
         }
         } elseif (!empty($form_errors)) {
         $error_message = '<ul style="margin: 0; padding-left: 20px;">';
            foreach ($form_errors as $err) {
            $error_message .= '<li>' . htmlspecialchars($err) . '</li>';
            }
         $error_message .= '</ul>';
    }
}

// ============================================
// STATISTICS AND UI
// ============================================

$query = "SELECT 
            COUNT(*) as total_today,
            SUM(CASE WHEN priority_level = 'PR1' THEN 1 ELSE 0 END) as pr1_count,
            SUM(CASE WHEN priority_level = 'PR2' THEN 1 ELSE 0 END) as pr2_count,
            SUM(CASE WHEN priority_level = 'PR3' THEN 1 ELSE 0 END) as pr3_count
          FROM queue_entries 
          WHERE DATE(registered_at) = CURDATE()";
$stats = $db->query($query)->fetch(PDO::FETCH_ASSOC);

$today_date = date('Y-m-d');
$min_date = date('Y-m-d', strtotime('-120 years'));

// Set dark mode as default
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = 'dark';
}
$current_theme = $_SESSION['theme'];
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo ($current_theme === 'dark') ? 'dark' : ''; ?> h-full">
<head>
    <script>
        (function () {
            var savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') document.documentElement.classList.add('dark');
            if (savedTheme === 'light') document.documentElement.classList.remove('dark');
        })();
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration | Staff | Camp Evangelista Hospital</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/images/logo.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', '-apple-system', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-slate-100 font-sans antialiased min-h-full transition-colors duration-200">

    <!-- Sidebar -->
    <aside id="sidebar" class="fixed top-0 left-0 h-screen bg-white dark:bg-[#1f2937] border-r border-slate-300/90 dark:border-slate-700/80 shadow-xl md:shadow-none z-[1000] flex flex-col overflow-x-hidden transition-all duration-300 ease-in-out group/sidebar -translate-x-full md:translate-x-0 w-[270px] md:w-[80px] md:hover:w-[270px]">
        <div>
            <div class="p-4 border-b border-slate-300/90 dark:border-slate-700/60 mb-6 flex flex-col items-center justify-center min-h-[150px]">
                <div class="hidden md:flex md:group-hover/sidebar:hidden flex-col items-center justify-center font-extrabold text-xl tracking-wider text-sky-600 dark:text-sky-400 leading-tight select-none">
                    <span>C</span><span>E</span><span>S</span><span>H</span>
                </div>
                <div class="flex md:hidden md:group-hover/sidebar:flex flex-col items-center animate-[fadeIn_0.2s_ease-in-out]">
                    <img src="../assets/images/logo.png" alt="Logo" class="max-w-[200px] h-auto rounded mb-3 opacity-90 transition-all duration-200 dark:brightness-110 dark:contrast-125 dark:drop-shadow-[0_0_8px_rgba(56,189,248,0.3)]" onerror="this.style.display='none'">
                    <h2 class="text-slate-800 dark:text-slate-100 text-sm font-extrabold tracking-tight text-center whitespace-nowrap">4ID Station Hospital</h2>
                    <p class="text-slate-400 dark:text-slate-400 text-[0.65rem] font-bold uppercase tracking-widest text-center whitespace-nowrap mt-0.5">Camp Evangelista</p>
                </div>
            </div>
            
            <nav class="px-3 md:group-hover/sidebar:px-4 transition-all duration-200">
                <ul class="list-none p-0 space-y-1">
                    <li>
                        <a href="clinic-dashboard.php?clinic_id=<?php echo $_SESSION['clinic_id'] ?? 1; ?>" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-tachometer-alt text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="registration.php" class="flex items-center rounded-xl font-semibold transition-all duration-150 bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 border-l-4 border-sky-500 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-user-plus text-base"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Register Patient</span>
                        </a>
                    </li>
                    <li>
                        <a href="patient-queue.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-list text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">All Clinics</span>
                        </a>
                    </li>
                    <li>
                        <a href="../patient-portal/track-queue.php" target="_blank" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                            <div class="w-6 h-6 flex items-center justify-center shrink-0">
                                <i class="fas fa-search text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                            </div>
                            <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Patient Portal</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        
        <!-- Bottom Section -->
        <div class="p-3 border-t border-slate-300/90 dark:border-slate-700/60">
            <div class="flex items-center justify-center md:group-hover/sidebar:hidden py-2">
                <div class="w-10 h-10 bg-sky-50 dark:bg-sky-500/10 rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700">
                    <i class="fas fa-user text-base"></i>
                </div>
            </div>
            
            <div class="hidden md:group-hover/sidebar:flex flex-col px-3 py-3 bg-sky-50 dark:bg-sky-500/10 rounded-xl mb-3 transition-all duration-300">
                <div class="text-[0.55rem] font-bold text-slate-400 dark:text-slate-400 uppercase tracking-wider">Logged in as</div>
                <div class="text-sm font-bold text-slate-800 dark:text-slate-200 truncate"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></div>
                <div class="text-[0.6rem] font-semibold text-sky-600 dark:text-sky-400">
                    <i class="fas fa-tag"></i> Role: <?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?>
                </div>
            </div>
            
            <a href="profile.php" class="flex items-center rounded-xl font-medium transition-all duration-150 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                <div class="w-6 h-6 flex items-center justify-center shrink-0">
                    <i class="fas fa-user-circle text-base text-slate-400 group-hover/link:text-sky-500 transition-colors"></i>
                </div>
                <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">My Profile</span>
            </a>
            <a href="../logout.php" onclick="return confirm('Are you sure you want to logout?')" class="flex items-center rounded-xl font-medium transition-all duration-150 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-3 justify-center md:justify-start gap-0 md:group-hover/sidebar:gap-3 border-l-4 border-transparent group/link">
                <div class="w-6 h-6 flex items-center justify-center shrink-0">
                    <i class="fas fa-sign-out-alt text-base"></i>
                </div>
                <span class="opacity-100 md:opacity-0 md:group-hover/sidebar:opacity-100 text-[0.85rem] tracking-wide whitespace-nowrap transition-opacity duration-200 origin-left">Logout</span>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="min-h-screen ml-0 md:ml-[80px] p-5 md:p-8 transition-all duration-300">
        
        <!-- Header -->
        <header class="flex flex-col sm:flex-row justify-between sm:items-center mb-8 pb-5 border-b border-slate-300/90 dark:border-slate-700/80 gap-4">
            <div class="flex items-center gap-4">
                <button id="mobileMenuBtn" class="md:hidden p-2 text-slate-600 dark:text-slate-300 bg-white dark:bg-[#1f2937] border border-slate-300 rounded-xl">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-slate-900 dark:text-white text-2xl md:text-3xl font-extrabold tracking-tight mb-0.5">Patient Registration</h1>
                    <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm font-medium">Register new patients or add existing patients to queue</p>
                </div>
            </div>
            
            <div class="flex items-center gap-3 md:gap-5 relative">
                <div class="text-right text-xs hidden sm:block">
                    <div class="text-slate-700 dark:text-slate-300 font-semibold" id="currentDate"></div>
                    <div class="text-sky-600 dark:text-sky-400 font-bold font-mono text-sm mt-0.5" id="currentTime"></div>
                </div>

                <button id="themeToggleBtn" class="w-10 h-10 flex items-center justify-center bg-white dark:bg-[#1f2937] text-slate-500 dark:text-slate-400 border border-slate-300 dark:border-slate-700 rounded-xl hover:text-sky-500 transition-all shadow-sm" title="Toggle Visual Mode">
                    <i id="themeToggleIcon" class="fas fa-moon text-base"></i>
                </button>

                <div class="relative">
                    <button id="profileMenuBtn" class="w-11 h-11 bg-white dark:bg-[#1f2937] rounded-full flex items-center justify-center text-sky-600 dark:text-sky-400 border border-slate-300 dark:border-slate-700 shadow-sm hover:border-sky-500 dark:hover:border-sky-400 focus:outline-none transition-all duration-150">
                        <i class="fas fa-user-md text-lg"></i>
                    </button>
                    
                    <div id="profileDropdown" class="hidden absolute right-0 mt-2.5 w-60 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xl z-[1100] animate-[modalFadeIn_0.15s_ease-out]">
                        <div class="p-4 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50 dark:bg-slate-800/40 rounded-t-xl">
                            <p class="text-xs font-bold text-slate-900 dark:text-white truncate"><?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></p>
                            <p class="text-[0.65rem] font-bold text-slate-400 uppercase tracking-wider truncate mt-0.5"><?php echo ucfirst(htmlspecialchars($_SESSION['role'])); ?></p>
                        </div>
                        <div class="p-1.5">
                            <a href="profile.php" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                                <i class="fas fa-user-circle text-sm"></i>
                                <span>My Profile</span>
                            </a>
                            <a href="../logout.php" onclick="return confirm('Confirm Logout?')" class="flex items-center gap-2.5 w-full text-left px-3 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-colors">
                                <i class="fas fa-power-off text-sm"></i>
                                <span>Logout Session</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Statistics -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mb-6">
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-sky-50 dark:bg-sky-500/10 rounded-lg flex items-center justify-center text-sky-600 dark:text-sky-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-users"></i>
                </div>
                <div class="text-lg font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['total_today'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">Total Today</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-rose-50 dark:bg-rose-500/10 rounded-lg flex items-center justify-center text-rose-600 dark:text-rose-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="text-lg font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['pr1_count'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">PR1 - Military</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-amber-50 dark:bg-amber-500/10 rounded-lg flex items-center justify-center text-amber-600 dark:text-amber-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-heart"></i>
                </div>
                <div class="text-lg font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['pr2_count'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">PR2 - Priority</div>
            </div>
            <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl p-3 shadow-sm hover:shadow-md transition-all text-center">
                <div class="w-8 h-8 bg-emerald-50 dark:bg-emerald-500/10 rounded-lg flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-sm mx-auto mb-1.5">
                    <i class="fas fa-user"></i>
                </div>
                <div class="text-lg font-bold text-slate-900 dark:text-white font-mono leading-none"><?php echo $stats['pr3_count'] ?? 0; ?></div>
                <div class="text-slate-400 dark:text-slate-400 text-[0.5rem] font-bold uppercase tracking-wider mt-0.5">PR3 - Regular</div>
            </div>
        </div>

        <!-- Alerts -->
        <?php if ($success_message): ?>
            <div class="p-4 mb-6 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center gap-3 shadow-sm flex-wrap">
                <i class="fas fa-check-circle text-base"></i>
                <span><?php echo $success_message; ?></span>
                <?php if ($last_registered_patient && $last_registered_patient['transaction_token']): ?>
                    <a href="print-ticket.php?token=<?php echo urlencode($last_registered_patient['transaction_token']); ?>" target="_blank" class="ml-auto bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-1.5">
                        <i class="fas fa-print"></i> Print Ticket
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
            <div class="p-4 mb-6 bg-rose-50 dark:bg-rose-500/10 border border-rose-300 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl flex items-center gap-3 shadow-sm">
                <i class="fas fa-exclamation-circle text-base"></i> <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <!-- Registration Form -->
        <div class="bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700/70 rounded-xl shadow-sm overflow-hidden">
            <div class="px-5 py-3.5 border-b border-slate-200 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20">
                <h3 class="text-xs font-bold uppercase text-slate-900 dark:text-white tracking-wider flex items-center gap-2">
                    <i class="fas fa-notes-medical text-sky-500 text-sm"></i> Patient Information
                </h3>
            </div>
            <div class="p-5">
                <!-- Toggle: New / Existing -->
                <div class="grid grid-cols-2 gap-2 mb-4 bg-slate-100 dark:bg-slate-800 rounded-xl p-1">
                    <button type="button" onclick="togglePatientType('new')" id="toggleNew" class="px-4 py-2 rounded-lg text-sm font-bold transition-all bg-sky-500 text-white">
                        <i class="fas fa-user-plus mr-1.5"></i> New Patient
                    </button>
                    <button type="button" onclick="togglePatientType('existing')" id="toggleExisting" class="px-4 py-2 rounded-lg text-sm font-bold transition-all text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700">
                        <i class="fas fa-search mr-1.5"></i> Existing Patient (CRM)
                    </button>
                </div>
                
                <!-- Existing Patient Search -->
                <div id="existingPatientSection" class="hidden mb-4">
                    <div class="mb-3">
                        <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5"><i class="fas fa-search mr-1 text-sky-500"></i> Search Existing Patient</label>
                        <div class="relative">
                            <input type="text" id="patientSearch" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" placeholder="Type name or MRN to search..." autocomplete="off">
                            <div id="searchResults" class="absolute top-full left-0 right-0 bg-white dark:bg-[#1f2937] border border-slate-300 dark:border-slate-700 rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto hidden"></div>
                        </div>
                        <input type="hidden" id="selectedPatientMrn" name="existing_mrn" value="">
                        <input type="hidden" id="useExisting" name="use_existing" value="0">
                    </div>
                    <div id="selectedPatientInfo" class="bg-sky-50 dark:bg-sky-500/10 border border-sky-200 dark:border-sky-500/20 rounded-xl p-3 flex justify-between items-center" style="display: none;">
                        <div>
                            <strong id="selectedPatientName" class="text-slate-900 dark:text-white"></strong>
                            <br><small id="selectedPatientDetails" class="text-slate-500 dark:text-slate-400"></small>
                        </div>
                        <button type="button" onclick="clearSelectedPatient()" class="text-rose-500 hover:text-rose-600 text-xs font-bold">Clear</button>
                    </div>
                </div>
                
                <form method="POST" id="registrationForm" onsubmit="return validateForm()">
                    <input type="hidden" id="useExistingInput" name="use_existing" value="0">
                    <input type="hidden" id="existingMrnInput" name="existing_mrn" value="">
                    
                    <div id="newPatientFields">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5 required">First Name</label>
                                <input type="text" name="first_name" id="first_name" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" required>
                            </div>
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5">Middle Name</label>
                                <input type="text" name="middle_name" id="middle_name" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all">
                            </div>
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5 required">Last Name</label>
                                <input type="text" name="last_name" id="last_name" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" required>
                            </div>
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5">Suffix</label>
                                <select name="suffix" id="suffix" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all">
                                    <option value="">None</option>
                                    <option value="Jr">Jr</option>
                                    <option value="Sr">Sr</option>
                                    <option value="II">II</option>
                                    <option value="III">III</option>
                                    <option value="IV">IV</option>
                                    <option value="V">V</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5 required">Date of Birth</label>
                                <input type="date" name="dob" id="dob" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" required min="<?php echo $min_date; ?>" max="<?php echo $today_date; ?>">
                            </div>
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5 required">Gender</label>
                                <select name="gender" id="gender" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" required>
                                    <option value="">Select</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5 required">Contact Number</label>
                                <input type="tel" name="contact" id="contact" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" placeholder="09123456789" required>
                            </div>
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5">Email Address</label>
                                <input type="email" name="email" id="email" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" placeholder="patient@email.com">
                                <p class="text-[0.5rem] text-slate-400 dark:text-slate-500 mt-0.5">Optional - Used for notifications and communication</p>
                            </div>
                            <div>
                                <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5 required">Address</label>
                                <input type="text" name="address" id="address" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" placeholder="Complete address" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                        <div>
                            <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5 required">Patient Type</label>
                            <select name="patient_type" id="patientType" class="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#111827] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-sm transition-all" required>
                                <option value="">Select Type</option>
                                <option value="dependent">Dependent</option>
                                <option value="military">Military Personnel</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5">Priority Conditions</label>
                            <div class="flex flex-wrap gap-3 pt-1.5">
                                <label class="flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                                    <input type="checkbox" name="is_pwd" id="isPwd" value="1" class="w-4 h-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 accent-sky-600 cursor-pointer">
                                    PWD
                                </label>
                                <label class="flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                                    <input type="checkbox" name="is_senior" id="isSenior" value="1" class="w-4 h-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 accent-sky-600 cursor-pointer">
                                    Senior
                                </label>
                                <label class="flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                                    <input type="checkbox" name="is_pregnant" id="isPregnant" value="1" class="w-4 h-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 accent-sky-600 cursor-pointer">
                                    Pregnant
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Priority Preview -->
                    <div id="priorityPreview" class="mt-3 p-3 bg-sky-50 dark:bg-sky-500/10 border border-sky-200 dark:border-sky-500/20 rounded-xl flex items-center justify-between flex-wrap gap-2">
                        <span class="text-xs font-medium text-slate-600 dark:text-slate-300"><i class="fas fa-info-circle text-sky-500 mr-1"></i> Priority Level:</span>
                        <div>
                            <span id="priorityBadge" class="inline-block px-3 py-0.5 rounded-full text-xs font-bold priority-PR3">PR3</span>
                            <span id="priorityDescription" class="text-xs font-medium text-slate-600 dark:text-slate-300 ml-2">Regular Patient</span>
                        </div>
                    </div>

                    <hr class="my-4 border-slate-200 dark:border-slate-700/60">

                    <!-- Clinic Selection -->
                    <div id="clinicMultiSelect">
                        <label class="block text-[0.6rem] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-400 mb-1.5">Select Clinics (In Order of Visit)</label>
                        <div class="border border-slate-300 dark:border-slate-700 rounded-xl overflow-hidden">
                            <div class="px-4 py-2 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-300 dark:border-slate-700 flex justify-between items-center">
                                <span class="text-xs text-slate-500 dark:text-slate-400"><i class="fas fa-info-circle mr-1"></i> Select clinics in order</span>
                                <button type="button" onclick="toggleAllClinics()" class="text-xs font-bold text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300 transition-colors">
                                    <i class="fas fa-check-double"></i> Select All
                                </button>
                            </div>
                            <div class="max-h-60 overflow-y-auto" id="clinicOptions">
                                <?php foreach ($clinics as $clinic): ?>
                                    <div class="flex items-center px-4 py-2.5 border-b border-slate-100 dark:border-slate-700/50 last:border-0 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors" data-id="<?php echo $clinic['id']; ?>" data-name="<?php echo htmlspecialchars($clinic['name']); ?>">
                                        <input type="checkbox" name="clinic_ids[]" value="<?php echo $clinic['id']; ?>" id="clinic_<?php echo $clinic['id']; ?>" class="w-4 h-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 accent-sky-600 cursor-pointer">
                                        <label for="clinic_<?php echo $clinic['id']; ?>" class="ml-2 text-sm font-medium text-slate-700 dark:text-slate-300 cursor-pointer flex-1">
                                            <?php echo htmlspecialchars($clinic['name']); ?>
                                            <span class="text-xs text-slate-400">(Capacity: <?php echo $clinic['capacity_per_hour']; ?>/hr)</span>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div id="journeyPreview" class="hidden mt-2 text-sm text-emerald-600 dark:text-emerald-400">
                            <i class="fas fa-route mr-1"></i> Journey: <span id="journeySequence"></span>
                        </div>
                        <p class="text-[0.55rem] text-slate-400 dark:text-slate-500 mt-1"><i class="fas fa-info-circle mr-1"></i> Patient will visit clinics in the order selected: <strong>Clinic 1 → Clinic 2 → Clinic 3 → ...</strong></p>
                    </div>

                    <div class="flex justify-end gap-3 mt-5 pt-4 border-t border-slate-200 dark:border-slate-700/60">
                        <button type="reset" onclick="resetForm()" class="px-5 py-2.5 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-all">
                            <i class="fas fa-undo-alt mr-1"></i> Clear
                        </button>
                        <button type="submit" name="register_patient" class="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl transition-all shadow-sm flex items-center justify-center gap-2">
                            <i class="fas fa-save"></i> Register Patient
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <style>
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }
        .required:after { content: " *"; color: #FF6F61; }
        .priority-PR1 { background: #FF6F61; color: white; }
        .priority-PR2 { background: #FFB84D; color: #333; }
        .priority-PR3 { background: #A4D1B1; color: #333; }
    </style>

    <script>
        // Theme Toggle
        var themeToggleBtn = document.getElementById('themeToggleBtn');
        var themeToggleIcon = document.getElementById('themeToggleIcon');
        var htmlElement = document.documentElement;

        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlElement.classList.add('dark');
            if (themeToggleIcon) {
                themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
            }
        } else {
            htmlElement.classList.remove('dark');
            if (themeToggleIcon) {
                themeToggleIcon.className = 'fas fa-moon text-base';
            }
        }

        if (themeToggleBtn) {
            themeToggleBtn.addEventListener('click', function() {
                if (htmlElement.classList.contains('dark')) {
                    htmlElement.classList.remove('dark');
                    if (themeToggleIcon) {
                        themeToggleIcon.className = 'fas fa-moon text-base';
                    }
                    localStorage.setItem('theme', 'light');
                } else {
                    htmlElement.classList.add('dark');
                    if (themeToggleIcon) {
                        themeToggleIcon.className = 'fas fa-sun text-base text-amber-400';
                    }
                    localStorage.setItem('theme', 'dark');
                }
            });
        }

        // Profile Dropdown
        var profileMenuBtn = document.getElementById('profileMenuBtn');
        var profileDropdown = document.getElementById('profileDropdown');

        if (profileMenuBtn && profileDropdown) {
            profileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdown.classList.toggle('hidden');
            });
            document.addEventListener('click', function(e) {
                if (!profileDropdown.contains(e.target) && e.target !== profileMenuBtn && !profileMenuBtn.contains(e.target)) {
                    profileDropdown.classList.add('hidden');
                }
            });
        }

        // Live Clock
        function updateDateTime() {
            var now = new Date();
            var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            var dateEl = document.getElementById('currentDate');
            var timeEl = document.getElementById('currentTime');
            if (dateEl) dateEl.textContent = now.toLocaleDateString('en-US', options);
            if (timeEl) timeEl.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Mobile Menu
        var mobileMenuBtn = document.getElementById('mobileMenuBtn');
        var sidebar = document.getElementById('sidebar');

        if (mobileMenuBtn && sidebar) {
            mobileMenuBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                sidebar.classList.toggle('-translate-x-full');
            });

            document.addEventListener('click', function(e) {
                if (window.innerWidth < 768) {
                    if (!sidebar.contains(e.target) && e.target !== mobileMenuBtn && !mobileMenuBtn.contains(e.target)) {
                        sidebar.classList.add('-translate-x-full');
                    }
                }
            });
        }

        // CRM Patients Data
        var crmPatients = <?php echo json_encode($crm_patients); ?>;
        var currentMode = 'new';
        var selectedPatient = null;

        function togglePatientType(type) {
            currentMode = type;
            var toggleNew = document.getElementById('toggleNew');
            var toggleExisting = document.getElementById('toggleExisting');
            var existingSection = document.getElementById('existingPatientSection');
            var newPatientFields = document.getElementById('newPatientFields');
            var useExistingInput = document.getElementById('useExistingInput');
            var existingMrnInput = document.getElementById('existingMrnInput');
            
            if (type === 'new') {
                toggleNew.className = 'px-4 py-2 rounded-lg text-sm font-bold transition-all bg-sky-500 text-white';
                toggleExisting.className = 'px-4 py-2 rounded-lg text-sm font-bold transition-all text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700';
                existingSection.classList.add('hidden');
                newPatientFields.style.display = 'block';
                useExistingInput.value = '0';
                existingMrnInput.value = '';
                document.getElementById('first_name').disabled = false;
                document.getElementById('middle_name').disabled = false;
                document.getElementById('last_name').disabled = false;
                document.getElementById('suffix').disabled = false;
                document.getElementById('dob').disabled = false;
                document.getElementById('gender').disabled = false;
                document.getElementById('contact').disabled = false;
                document.getElementById('email').disabled = false;
                document.getElementById('address').disabled = false;
                clearSelectedPatient();
            } else {
                toggleNew.className = 'px-4 py-2 rounded-lg text-sm font-bold transition-all text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700';
                toggleExisting.className = 'px-4 py-2 rounded-lg text-sm font-bold transition-all bg-sky-500 text-white';
                existingSection.classList.remove('hidden');
                newPatientFields.style.display = 'none';
                useExistingInput.value = '1';
                document.getElementById('first_name').disabled = true;
                document.getElementById('middle_name').disabled = false;
                document.getElementById('last_name').disabled = true;
                document.getElementById('suffix').disabled = false;
                document.getElementById('dob').disabled = true;
                document.getElementById('gender').disabled = true;
                document.getElementById('contact').disabled = false;
                document.getElementById('email').disabled = false;
                document.getElementById('address').disabled = false;
            }
        }

        function validateForm() {
            var isValid = true;
            var email = document.getElementById('email').value.trim();
            var namePattern = /^[\p{L} -]+$/u;
            var nameInputs = ['first_name', 'middle_name', 'last_name', 'suffix'];
            var invalidName = nameInputs.find(function(id) {
                var input = document.getElementById(id);
                var value = input.value.trim();
                return !input.disabled && value !== '' && !namePattern.test(value);
            });
            if (invalidName) {
                alert('Name fields may contain letters, spaces, and hyphens (-) only.');
                document.getElementById(invalidName).focus();
                return false;
            }
            
            // Validate email format if provided
            if (email !== '') {
                var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    isValid = false;
                    alert('Please enter a valid email address.');
                    document.getElementById('email').focus();
                    return false;
                }
            }
            
            if (currentMode === 'new') {
                var firstName = document.getElementById('first_name').value.trim();
                if (firstName === '') { isValid = false; }
                var lastName = document.getElementById('last_name').value.trim();
                if (lastName === '') { isValid = false; }
                var dob = document.getElementById('dob').value;
                if (dob === '') { isValid = false; }
                var gender = document.getElementById('gender').value;
                if (gender === '') { isValid = false; }
                var patientType = document.getElementById('patientType').value;
                if (patientType === '') { isValid = false; }
                var contact = document.getElementById('contact').value.trim();
                if (contact === '') { 
                    isValid = false; 
                } else {
                    var cleanContact = contact.replace(/[^0-9]/g, '');
                    if (cleanContact.length !== 11 || !cleanContact.startsWith('09')) {
                        isValid = false;
                    }
                }
                var address = document.getElementById('address').value.trim();
                if (address === '') { isValid = false; }
            } else {
                var contact = document.getElementById('contact').value.trim();
                if (contact !== '') {
                    var cleanContact = contact.replace(/[^0-9]/g, '');
                    if (cleanContact.length !== 11 || !cleanContact.startsWith('09')) {
                        isValid = false;
                    }
                }
                var address = document.getElementById('address').value.trim();
                if (address === '') { isValid = false; }
                var selectedMrn = document.getElementById('selectedPatientMrn').value;
                if (selectedMrn === '') { isValid = false; }
            }
            
            if (!isValid) {
                alert('Please fill in all required fields correctly.');
            }
            return isValid;
        }

        function resetForm() {
            document.getElementById('first_name').value = '';
            document.getElementById('middle_name').value = '';
            document.getElementById('last_name').value = '';
            document.getElementById('suffix').value = '';
            document.getElementById('dob').value = '';
            document.getElementById('gender').value = '';
            document.getElementById('contact').value = '';
            document.getElementById('email').value = '';
            document.getElementById('address').value = '';
            document.getElementById('patientType').value = '';
            document.getElementById('isPwd').checked = false;
            document.getElementById('isSenior').checked = false;
            document.getElementById('isPregnant').checked = false;
            document.querySelectorAll('input[name="clinic_ids[]"]').forEach(function(cb) { cb.checked = false; });
            updateJourneyPreview();
            updatePriorityPreview();
            clearSelectedPatient();
            document.getElementById('selectedPatientInfo').style.display = 'none';
        }

        function searchPatients() {
            var searchTerm = document.getElementById('patientSearch').value.toLowerCase();
            var resultsDiv = document.getElementById('searchResults');
            if (searchTerm.length < 2) {
                resultsDiv.classList.add('hidden');
                return;
            }
            var filtered = crmPatients.filter(function(p) {
                var nameMatch = (p.first_name && p.first_name.toLowerCase().includes(searchTerm)) || 
                               (p.last_name && p.last_name.toLowerCase().includes(searchTerm));
                var mrnMatch = p.mrn && p.mrn.toString().includes(searchTerm);
                return nameMatch || mrnMatch;
            });
            
            if (filtered.length > 0) {
                resultsDiv.innerHTML = filtered.map(function(p) {
                    return '<div class="px-4 py-2.5 hover:bg-sky-50 dark:hover:bg-sky-500/10 cursor-pointer border-b border-slate-100 dark:border-slate-700/50 last:border-0" onclick="selectPatient(' + p.mrn + ')"><div class="font-bold text-slate-800 dark:text-slate-200">' + escapeHtml(p.last_name || '') + ', ' + escapeHtml(p.first_name || '') + '</div><div class="text-xs text-slate-500 dark:text-slate-400">MRN: ' + p.mrn + ' | ' + (p.gender || 'N/A') + '</div></div>';
                }).join('');
                resultsDiv.classList.remove('hidden');
            } else {
                resultsDiv.innerHTML = '<div class="px-4 py-2.5 text-slate-400">No patients found</div>';
                resultsDiv.classList.remove('hidden');
            }
        }

        function escapeHtml(str) {
            if (!str) return '';
            return str.replace(/[&<>]/g, function(m) {
                if (m === '&') return '&amp;';
                if (m === '<') return '&lt;';
                if (m === '>') return '&gt;';
                return m;
            });
        }

        function selectPatient(mrn) {
            var patient = crmPatients.find(function(p) { return p.mrn == mrn; });
            if (patient) {
                selectedPatient = patient;
                document.getElementById('first_name').value = patient.first_name || '';
                document.getElementById('last_name').value = patient.last_name || '';
                document.getElementById('dob').value = patient.dob || '';
                document.getElementById('gender').value = patient.gender || '';
                document.getElementById('contact').value = patient.contact || '';
                document.getElementById('address').value = patient.address || '';
                document.getElementById('existingMrnInput').value = patient.mrn;
                document.getElementById('selectedPatientMrn').value = patient.mrn;
                
                var selectedInfo = document.getElementById('selectedPatientInfo');
                document.getElementById('selectedPatientName').innerHTML = escapeHtml(patient.last_name || '') + ', ' + escapeHtml(patient.first_name || '');
                document.getElementById('selectedPatientDetails').innerHTML = 'MRN: ' + patient.mrn + ' | DOB: ' + (patient.dob || 'N/A') + ' | ' + (patient.gender || 'N/A');
                selectedInfo.style.display = 'flex';
                document.getElementById('searchResults').classList.add('hidden');
                document.getElementById('patientSearch').value = '';
            }
        }

        function clearSelectedPatient() {
            selectedPatient = null;
            document.getElementById('selectedPatientInfo').style.display = 'none';
            document.getElementById('selectedPatientMrn').value = '';
            document.getElementById('existingMrnInput').value = '';
            document.getElementById('patientSearch').value = '';
            document.getElementById('searchResults').classList.add('hidden');
            if (currentMode === 'new') {
                document.getElementById('first_name').value = '';
                document.getElementById('middle_name').value = '';
                document.getElementById('last_name').value = '';
                document.getElementById('suffix').value = '';
                document.getElementById('dob').value = '';
                document.getElementById('gender').value = '';
                document.getElementById('contact').value = '';
                document.getElementById('email').value = '';
                document.getElementById('address').value = '';
            }
        }

        document.getElementById('patientSearch').addEventListener('input', searchPatients);
        document.addEventListener('click', function(e) {
            var searchWrapper = document.querySelector('.relative');
            if (searchWrapper && !searchWrapper.contains(e.target)) {
                document.getElementById('searchResults').classList.add('hidden');
            }
        });

        function updatePriorityPreview() {
            var patientType = document.getElementById('patientType').value;
            var isPwd = document.getElementById('isPwd').checked;
            var isSenior = document.getElementById('isSenior').checked;
            var isPregnant = document.getElementById('isPregnant').checked;
            var clinicMultiSelect = document.getElementById('clinicMultiSelect');
            var priority = 'PR3';
            var priorityClass = 'priority-PR3';
            var description = 'Regular Patient';
            
            if (patientType === 'military') {
                priority = 'PR1';
                priorityClass = 'priority-PR1';
                description = 'Military Personnel (Auto-queue for ALL clinics)';
                if (clinicMultiSelect) clinicMultiSelect.style.display = 'none';
            } else {
                if (clinicMultiSelect) clinicMultiSelect.style.display = 'block';
                if (isPwd || isSenior || isPregnant) {
                    priority = 'PR2';
                    priorityClass = 'priority-PR2';
                    var conditions = [];
                    if (isPwd) conditions.push('PWD');
                    if (isSenior) conditions.push('Senior');
                    if (isPregnant) conditions.push('Pregnant');
                    description = 'Priority (' + conditions.join(', ') + ')';
                }
            }
            
            var preview = document.getElementById('priorityPreview');
            var badge = document.getElementById('priorityBadge');
            var desc = document.getElementById('priorityDescription');
            
            if (patientType || isPwd || isSenior || isPregnant) {
                preview.classList.remove('hidden');
                badge.className = 'inline-block px-3 py-0.5 rounded-full text-xs font-bold ' + priorityClass;
                badge.textContent = priority;
                desc.textContent = description;
            } else {
                preview.classList.add('hidden');
            }
        }

        function updateJourneyPreview() {
            var checkboxes = document.querySelectorAll('input[name="clinic_ids[]"]:checked');
            var selectedNames = Array.from(checkboxes).map(function(cb) {
                var parent = cb.closest('.flex');
                return parent ? parent.dataset.name : '';
            });
            var journeyPreview = document.getElementById('journeyPreview');
            var journeySequence = document.getElementById('journeySequence');
            
            if (selectedNames.length > 0) {
                journeyPreview.classList.remove('hidden');
                journeySequence.innerHTML = selectedNames.join(' <i class="fas fa-arrow-right text-xs"></i> ');
            } else {
                journeyPreview.classList.add('hidden');
                journeySequence.innerHTML = '';
            }
        }

        function toggleAllClinics() {
            var checkboxes = document.querySelectorAll('input[name="clinic_ids[]"]');
            var allChecked = Array.from(checkboxes).every(function(cb) { return cb.checked; });
            checkboxes.forEach(function(checkbox) { checkbox.checked = !allChecked; });
            updateJourneyPreview();
            var btn = document.querySelector('.text-xs.font-bold.text-sky-600');
            if (btn) {
                var anyChecked = Array.from(checkboxes).some(function(cb) { return cb.checked; });
                btn.innerHTML = anyChecked ? '<i class="fas fa-times"></i> Deselect All' : '<i class="fas fa-check-double"></i> Select All';
            }
        }

        document.getElementById('patientType').addEventListener('change', updatePriorityPreview);
        document.getElementById('isPwd').addEventListener('change', updatePriorityPreview);
        document.getElementById('isSenior').addEventListener('change', updatePriorityPreview);
        document.getElementById('isPregnant').addEventListener('change', updatePriorityPreview);
        document.querySelectorAll('input[name="clinic_ids[]"]').forEach(function(checkbox) {
            checkbox.addEventListener('change', updateJourneyPreview);
        });

        updateJourneyPreview();
        updatePriorityPreview();

        // Auto-dismiss alerts
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(function(alert) {
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(function() { alert.remove(); }, 500);
            });
        }, 5000);

        // Auto Logout
        var INACTIVITY_TIMEOUT = 30 * 60 * 1000;
        var inactivityTimer;
        var warningTimer;
        var warningShown = false;

        function resetInactivityTimer() {
            if (inactivityTimer) clearTimeout(inactivityTimer);
            if (warningTimer) clearTimeout(warningTimer);
            warningShown = false;
            hideWarningModal();
            
            inactivityTimer = setTimeout(logoutUser, INACTIVITY_TIMEOUT);
            warningTimer = setTimeout(showWarningModal, INACTIVITY_TIMEOUT - (2 * 60 * 1000));
            sendHeartbeat();
        }

        function sendHeartbeat() {
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .catch(function(err) { console.log('Heartbeat failed:', err); });
        }

        function logoutUser() {
            var logoutMsg = document.createElement('div');
            logoutMsg.innerHTML = "<div class=\"fixed inset-0 bg-slate-900/85 backdrop-blur-sm z-[9999] flex items-center justify-center p-4\"><div class=\"bg-white dark:bg-[#1f2937] p-8 rounded-xl text-center max-w-[400px] shadow-2xl border border-slate-200 dark:border-slate-700\"><i class=\"fas fa-clock text-5xl text-rose-500 mb-5\"></i><h3 class=\"text-xl font-bold text-slate-900 dark:text-white mb-2\">Session Expired</h3><p class=\"text-slate-500 dark:text-slate-400 text-sm mb-5\">You have been logged out due to inactivity.</p><div class=\"w-full bg-slate-200 dark:bg-slate-700 h-1 rounded-full overflow-hidden\"><div class=\"bg-sky-500 h-full animate-[pulse_2s_ease-in-out_infinite] w-full\"></div></div></div></div>";
            document.body.appendChild(logoutMsg);
            setTimeout(function() { window.location.href = '../logout.php'; }, 2000);
        }

        function showWarningModal() {
            if (warningShown) return;
            warningShown = true;
            
            var modal = document.createElement('div');
            modal.id = 'sessionWarningModal';
            modal.innerHTML = "<div class=\"fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[10000] flex items-center justify-center p-4\"><div class=\"bg-white dark:bg-[#1f2937] p-6 rounded-xl text-center max-w-[400px] shadow-2xl border border-amber-200 dark:border-amber-500/20 animate-modal-fade-in\"><i class=\"fas fa-hourglass-half text-5xl text-amber-500 mb-4\"></i><h3 class=\"text-lg font-bold text-slate-900 dark:text-white mb-1\">Session About to Expire</h3><p class=\"text-slate-500 dark:text-slate-400 text-sm mb-3\">You will be logged out due to inactivity.</p><p id=\"countdownText\" class=\"text-3xl font-black text-amber-600 dark:text-amber-400 tracking-wider mb-4\">2:00</p><button onclick=\"keepSessionAlive()\" class=\"w-full bg-sky-500 hover:bg-sky-600 text-white py-2.5 px-4 rounded-xl font-bold transition-colors shadow-md text-sm\"><i class=\"fas fa-mouse-pointer mr-1.5\"></i> Keep Session Active</button></div></div>";
            document.body.appendChild(modal);
            
            var secondsLeft = 120;
            var countdownElement = document.getElementById('countdownText');
            var countdownInterval = setInterval(function() {
                secondsLeft--;
                var minutes = Math.floor(secondsLeft / 60);
                var seconds = secondsLeft % 60;
                if (countdownElement) {
                    countdownElement.textContent = minutes + ':' + (seconds.toString().padStart(2, '0'));
                }
                if (secondsLeft <= 0) clearInterval(countdownInterval);
            }, 1000);
        }

        function keepSessionAlive() {
            hideWarningModal();
            fetch('heartbeat.php', { method: 'POST', credentials: 'same-origin' })
                .then(function() { resetInactivityTimer(); })
                .catch(function() { resetInactivityTimer(); });
        }

        function hideWarningModal() {
            var modal = document.getElementById('sessionWarningModal');
            if (modal) modal.remove();
        }

        var events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click', 'keydown'];
        events.forEach(function(event) {
            document.addEventListener(event, resetInactivityTimer, false);
        });

        resetInactivityTimer();
        setInterval(function() {
            if (!warningShown) sendHeartbeat();
        }, 5 * 60 * 1000);
    </script>

</body>
</html>